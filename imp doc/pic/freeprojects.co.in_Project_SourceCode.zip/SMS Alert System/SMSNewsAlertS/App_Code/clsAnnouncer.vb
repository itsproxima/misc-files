Imports System.Configuration


Namespace SMSNewsAlertS


Public Class clsAnnouncer

    Private sqlConnectionString As String

    Private Function sqlConstring() As String
        Me.sqlConnectionString = System.Configuration.ConfigurationSettings.AppSettings("SQLString")
        Return Me.sqlConnectionString
    End Function
    Public ReadOnly Property getConString() As String
        Get
            Return sqlConstring()
        End Get
    End Property

    Private Function getrandonumber(ByVal lowerbound, ByVal upperbound)
        Randomize()
        getrandonumber = Int((upperbound - lowerbound) * Rnd() + lowerbound)
    End Function

    Public Function GenerateNo()
        Dim mNo As Int64
        Dim a As Integer
        Dim dd As Integer
        dd = Now.DayOfWeek
        mNo = Now.Year & Now.Month & DatePart(DateInterval.Day, Now) & Now.Hour & Now.Second & getrandonumber(1, 10000)
        GenerateNo = mNo
    End Function

End Class

End Namespace
