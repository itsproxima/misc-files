Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Mail


Namespace SMSNewsAlertS

Partial Class ForgotPassword
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label


    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label3.Visible = False
    End Sub
    Dim ConStr As String
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Dim clsAnn As New clsAnnouncer
        ConStr = clsAnn.getConString()
        Dim infosqlcon As New SqlConnection(ConStr)
        Dim str, tempuser, temppass, mtype As String
        Dim count As Integer
        da.Dispose()
        ds.Clear()
        str = "select PWD,email from admin  where Uname='" & txtUsername.Text & "' and email ='" + txtemail.Text + "'"
        da.SelectCommand = New SqlCommand(str, infosqlcon)
        da.Fill(ds, "user")
        count = ds.Tables(0).Rows.Count

        If count = 1 Then
            Label3.Visible = True
            Label3.Text = "Your Password is :" + ds.Tables(0).Rows(0)(0).ToString()
        Else
            Label3.Visible = True
            Label3.Text = "You are not authorized person"
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Response.Redirect("default.aspx")
    End Sub
End Class

End Namespace
