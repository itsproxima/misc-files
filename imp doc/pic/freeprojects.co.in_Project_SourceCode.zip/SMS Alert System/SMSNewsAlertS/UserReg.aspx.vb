Imports System
Imports System.Data.SqlClient


Namespace SMSNewsAlertS


Partial Class UserReg
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim ConStr As String
    Dim da As SqlDataAdapter
    Dim ds As New DataSet
    Dim cmd As SqlCommand
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            Try
                CatFillDdl()
            Catch ex As Exception
                lblMsg.Visible = True
                lblMsg.Text = ex.Message
            End Try
        End If
    End Sub
    Public Sub CatFillDdl()
        Dim clsAnn As New clsAnnouncer
        ConStr = clsAnn.getConString()
        Dim infosqlcon As New SqlConnection(ConStr)
        da = New SqlDataAdapter("select * from CategoryInfo", infosqlcon)
        da.Fill(ds, "CategoryName")
        ddlCategoryName.DataSource = ds
        ddlCategoryName.DataTextField = ds.Tables(0).Columns("Category_Name").ToString()
        ddlCategoryName.DataValueField = ds.Tables(0).Columns("CategoryId").ToString()
        ddlCategoryName.DataBind()
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Dim clsAnn As New clsAnnouncer
        ConStr = clsAnn.getConString()
        Dim infosqlcon As New SqlConnection(ConStr)
        Try
            Dim sqlstr As String
            sqlstr = String.Format("insert into User_Details(User_Name,Hand_Phone_No,CategoryId,Email_Id,Pwd) values('" & txtUserName.Text & "'," & txtHand_Phone_No.Text & "," & ddlCategoryName.SelectedValue & ",'" & txtEmailId.Text & "','" & txtPassword.Text & "')")
            infosqlcon.Open()
            cmd = New SqlCommand(sqlstr, infosqlcon)
            cmd.ExecuteNonQuery()
            lblMsg.Visible = True
            lblMsg.Text = "Record Inserted"
            infosqlcon.Close()
            txtUserName.Text = ""
            txtHand_Phone_No.Text = ""
            txtEmailId.Text = ""
            txtPassword.Text = ""
        Catch ex As Exception
            lblMsg.Visible = True
            lblMsg.Text = ex.Message
        End Try
    End Sub

    Private Sub btnCancle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancle.Click
        Response.Redirect("default.aspx")
    End Sub
End Class

End Namespace
