Imports System
Imports System.Data.SqlClient


Namespace SMSNewsAlertS

Partial Class ChangeUserInfo
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim ConStr As String
    Dim da As New SqlDataAdapter
    Dim ds, ds1 As New DataSet
    Dim cmd As SqlCommand
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Session("LUser") = "" Then
            Response.Redirect("default.aspx")
        End If
        Try
            If Not IsPostBack Then
                CatFillDdl()
                FillUserInfo()
            End If
        Catch ex As Exception
            lblMsg.Visible = True
            lblMsg.Text = ex.Message
        End Try

    End Sub
    Public Sub FillUserInfo()
        Dim clsAnn As New clsAnnouncer
        ConStr = clsAnn.getConString()
        Dim infosqlcon As New SqlConnection(ConStr)
        Dim str, tempuser As String
        tempuser = Session("LUser")
        str = "select [User_Name],Hand_phone_No,Category_Name,Email_id from User_Details inner join CategoryInfo on User_Details.CategoryId=CategoryInfo.CategoryId where User_Details.Email_id ='" & Trim(tempuser) & "'"
        da.SelectCommand = New SqlCommand(str, infosqlcon)
        da.Fill(ds1, "userInfo")
        txtUserName.Text = ds1.Tables(0).Rows(0).Item(0)
        txtMobileNo.Text = ds1.Tables(0).Rows(0).Item(1)
        txtEmailId.Text = ds1.Tables(0).Rows(0).Item(3)
    End Sub
    Public Sub CatFillDdl()
        Dim clsAnn As New clsAnnouncer
        ConStr = clsAnn.getConString()
        Dim infosqlcon As New SqlConnection(ConStr)
        da = New SqlDataAdapter("select * from CategoryInfo", infosqlcon)
        da.Fill(ds, "CategoryName")
        ddlCategoryName.DataSource = ds
        ddlCategoryName.DataTextField = ds.Tables(0).Columns("Category_Name").ToString()
        ddlCategoryName.DataValueField = ds.Tables(0).Columns("CategoryId").ToString()
        ddlCategoryName.DataBind()
    End Sub


    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Dim clsAnn As New clsAnnouncer
        ConStr = clsAnn.getConString()
        Dim infosqlcon As New SqlConnection(ConStr)
        Try
            Dim sqlstr, uname As String
            uname = Session("LUser")
            sqlstr = String.Format("Update User_Details set User_Name='" & txtUserName.Text & "',Hand_Phone_No=" & txtMobileNo.Text & ",CategoryId=" & ddlCategoryName.SelectedValue & " where Email_Id='" & uname & "'")
            infosqlcon.Open()
            cmd = New SqlCommand(sqlstr, infosqlcon)
            cmd.ExecuteNonQuery()
            lblMsg.Visible = True
            lblMsg.Text = "Record Updated"
            infosqlcon.Close()
            txtUserName.Text = ""
            txtMobileNo.Text = ""
                txtEmailId.Text = ""
        Catch ex As Exception
            lblMsg.Visible = True
            lblMsg.Text = ex.Message
        End Try
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("UserIndex.aspx")
    End Sub
End Class

End Namespace
