Imports System
Imports System.Data.SqlClient


Namespace SMSNewsAlertS

Partial Class ViewAllUsers
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim ConStr As String
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Session("LUser") = "" Then
            Response.Redirect("default.aspx")
        End If
        Try
            If Not IsPostBack Then
                FillDataGrid()
            End If
        Catch ex As Exception
            lblMsg.Visible = True
            lblMsg.Text = ex.Message
        End Try
    End Sub
    Public Sub FillDataGrid()

        Dim clsAnn As New clsAnnouncer
        ConStr = clsAnn.getConString()
        Dim infosqlcon As New SqlConnection(ConStr)
        Dim str, tempuser As String
        tempuser = Session("LUser")
            str = "select [User_Name],Hand_phone_No,Category_Name,Email_id from User_Details inner join CategoryInfo on User_Details.CategoryId=CategoryInfo.CategoryId"
        da.SelectCommand = New SqlCommand(Str, infosqlcon)
        da.Fill(ds, "userInfo")
        grUserDetails1.DataSource = ds
        grUserDetails1.DataBind()

    End Sub

        Protected Sub grUserDetails1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grUserDetails1.SelectedIndexChanged
            'Public Sub grUserDetails1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grUserDetails1.SelectedIndexChanged
        End Sub
    End Class

End Namespace
